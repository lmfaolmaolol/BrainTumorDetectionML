# brain tumor detection > mahitha
https://universe.roboflow.com/brain-tumor-jolxi/brain-tumor-detection-o0ggc

Provided by a Roboflow user
License: Public Domain

